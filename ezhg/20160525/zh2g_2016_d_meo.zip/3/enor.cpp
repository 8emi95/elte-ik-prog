#include "enor.h"
#include <sstream>

using namespace std;

Enor::Enor(string fnev)
{
    x.open(fnev.c_str());
    vege = x.fail();
}

Enor::~Enor()
{
    x.close();
}

void Enor::First()
{
    Next();
}


void Enor::Next()
{
    string sor;
    getline(x,sor);
    if(x.fail())
    {
        vege = true;
    }
    else
    {
        stringstream ss(sor);
        ss>>dx.azonosito;

        string sv;
        dx.legkorabbi = "";
        ss>>sv; //maxkiv elso elemenek beolvasasa
        if(!ss.fail()) //ha nem utazott, marad ures a string
        {
            dx.legkorabbi = sv; //inicializalom a maxot az elsore
            ss>>sv; //atugrom az elso jaratszamot, az nem erdekel most engem

            while(ss>>sv)   //idokod beolvasasa
            {
                if(sv < dx.legkorabbi)
                {
                    dx.legkorabbi = sv;
                }
                ss>>sv; //jarat beolvasasa (es eldobasa)
            }
        }
    }
}

bool Enor::End() const
{
    return vege;
}

Utas Enor::Current() const
{
    return dx;
}
